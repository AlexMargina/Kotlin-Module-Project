import java.util.*

class MenuSelect (val level : MenuLevel) {

    // Функция для создания разных уровней меню. Уровень меню опредлеяется параметром level
    // Функция принимект на вход массив Map, содержащий заметки для построения их спика
    // Функция возвращает количество созданных пунктов меню.
    fun createMenu(level: MenuLevel, mapNotes: MapNotes, mapArhiv: MapArhiv) : Int {

        println("Введите число соответствующее пункту меню: ")
        if (level == MenuLevel.MainMenu) {    //Главный уровень меню
            println("1. Создать архив")
            println("2. Открыть имеющийся архив")
            println("3. Выход из программы")
            return 3

        } else if (level == MenuLevel.ArhivMenu) {  // Уровень меню архивов
            val numPoints = mapArhiv.mapArhiv.size
            println("1. ${level.menuPoint()}")
            for (i in 2..numPoints + 1) {
                val arhives = mapArhiv.mapArhiv.keys.toList()[i - 2]
                println("$i. $arhives")
            }
            println("${numPoints + 2}. Возврат в предыдущее меню")
            return numPoints + 2

        } else if (level == MenuLevel.NoteMenu) {    // Уровень меню заметок
            val numPoints = mapNotes.mapNotes.size
            println("1. ${level.menuPoint()}")
            for (i in 2..numPoints + 1) {
                val notes = mapNotes.mapNotes.keys.toList()[i - 2]
                println("$i. $notes")
            }
            println("${numPoints + 2}. Возврат в предыдущее меню")
            return numPoints + 2

        } else {
            return 0
        }

    }


    fun readMenu(numPoints: Int): Int {
        val input = Scanner(System.`in`)

        while (true) {
            if (input.hasNextInt()) {
                val SelectPoint = (input.nextInt())
                for (i in 1..numPoints) {
                    if (SelectPoint == i) {
                        println("Запускаем пункт $i")
                    }
                    return SelectPoint
                }
                if (SelectPoint == numPoints + 1) {
                    println("Возврат на предыдущее меню")
                    return SelectPoint
                }
                if (SelectPoint > numPoints + 1) {
                    println("Введите другое число")
                }
            } else {
                println("Введите число!")
                input.next()
            }
        }
    }

}

enum class MenuLevel (val level: String) // конструктор
{
    MainMenu    ("Главное меню"),
    ArhivMenu   ("Архив"),
    NoteMenu    ("Заметка"),
;
    // метод класса
    fun menuPoint(): String {
        return when (this) {
            MainMenu    -> "Главное меню"
            ArhivMenu   -> "Создать архив"
            NoteMenu -> "Создать заметку"
        }
    }
}